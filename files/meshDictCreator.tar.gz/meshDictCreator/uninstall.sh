#!/usr/bin/env bash

###############################################################################
# meshDictCreator Uninstaller
###############################################################################

set -e

echo
echo "=================================================="
echo "        meshDictCreator Uninstaller"
echo "=================================================="
echo

###############################################################################
# Check OpenFOAM
###############################################################################

printf "[1/4] Checking OpenFOAM environment... "

if [[ "$WM_PROJECT" != "OpenFOAM" ]]; then
    echo "FAILED"
    echo
    echo "OpenFOAM environment is not loaded."
    exit 1
fi

echo "OK"

###############################################################################
# Remove executables
###############################################################################

printf "[2/4] Removing executables... "

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN_DIR="$SCRIPT_DIR/bin"

count=0

for tool in "$BIN_DIR"/*; do

    [[ -f "$tool" ]] || continue

    name=$(basename "$tool")

    if [[ -f "$FOAM_USER_APPBIN/$name" ]]; then
        rm -f "$FOAM_USER_APPBIN/$name"
        ((count++))
    fi

done

echo "OK ($count removed)"

###############################################################################
# Remove libraries
###############################################################################

printf "[3/4] Removing PatchView libraries... "

rm -rf "$HOME/.meshDictCreator"

echo "OK"

###############################################################################
# Refresh shell
###############################################################################

printf "[4/4] Refreshing shell cache... "

hash -r

echo "OK"

echo
echo "=================================================="
echo "Uninstallation completed."
echo "=================================================="