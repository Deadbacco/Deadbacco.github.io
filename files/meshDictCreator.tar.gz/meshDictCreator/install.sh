#!/usr/bin/env bash

###############################################################################
# meshDictCreator Installer
###############################################################################

set -e

echo
echo "=================================================="
echo "         meshDictCreator Installer"
echo "=================================================="
echo

###############################################################################
# Check OpenFOAM
###############################################################################

printf "[1/7] Checking OpenFOAM environment... "

if [[ "$WM_PROJECT" != "OpenFOAM" ]]; then
    echo "FAILED"
    echo
    echo "OpenFOAM environment is not loaded."
    echo
    echo "Run:"
    echo "source /opt/openfoam12/etc/bashrc"
    exit 1
fi

echo "OK"

###############################################################################
# Check Python
###############################################################################

printf "[2/7] Checking Python3... "

command -v python3 >/dev/null 2>&1 || {
    echo "FAILED"
    echo "Python3 is required."
    exit 1
}

echo "OK"

###############################################################################
# Check PowerShell
###############################################################################

printf "[3/7] Checking PowerShell... "

PS="/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"

if [[ ! -f "$PS" ]]; then
    echo "FAILED"
    echo "PowerShell not found."
    exit 1
fi

echo "OK"

###############################################################################
# Check library files
###############################################################################

printf "[4/7] Checking project files... "

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

BIN_DIR="$SCRIPT_DIR/bin"
LIB_SRC="$SCRIPT_DIR/lib"

[[ -f "$BIN_DIR/meshDictCreator" ]] || { echo "FAILED"; exit 1; }
[[ -f "$BIN_DIR/patchview" ]] || { echo "FAILED"; exit 1; }
[[ -f "$LIB_SRC/patchview_split.py" ]] || { echo "FAILED"; exit 1; }
[[ -f "$LIB_SRC/patchview_build.py" ]] || { echo "FAILED"; exit 1; }

echo "OK"

###############################################################################
# Install executables
###############################################################################

printf "[5/7] Installing executables... "

mkdir -p "$FOAM_USER_APPBIN"

for tool in "$BIN_DIR"/*; do
    [[ -f "$tool" ]] || continue
    cp "$tool" "$FOAM_USER_APPBIN/"
    chmod +x "$FOAM_USER_APPBIN/$(basename "$tool")"
done

echo "OK"

###############################################################################
# Install libraries
###############################################################################

printf "[6/7] Installing PatchView libraries... "

INSTALL_LIB="$HOME/.meshDictCreator/lib"

mkdir -p "$INSTALL_LIB"

cp "$LIB_SRC"/*.py "$INSTALL_LIB/"

chmod +x "$INSTALL_LIB"/*.py

echo "OK"

###############################################################################
# Verify installation
###############################################################################

printf "[7/7] Verifying installation... "

hash -r

command -v meshDictCreator >/dev/null || {
    echo "FAILED"
    exit 1
}

command -v patchview >/dev/null || {
    echo "FAILED"
    exit 1
}

[[ -f "$INSTALL_LIB/patchview_split.py" ]] || {
    echo "FAILED"
    exit 1
}

[[ -f "$INSTALL_LIB/patchview_build.py" ]] || {
    echo "FAILED"
    exit 1
}

echo "OK"

echo
echo "=================================================="
echo "Installation completed successfully."
echo
echo "Installed executables:"
echo "  $FOAM_USER_APPBIN"
echo
echo "Installed libraries:"
echo "  $INSTALL_LIB"
echo
echo "=================================================="