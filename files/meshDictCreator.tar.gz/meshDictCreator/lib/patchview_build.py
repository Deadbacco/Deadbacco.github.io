#!/usr/bin/env python3

from paraview.simple import *
import glob
import os
import sys

if len(sys.argv) != 3:
    print("Usage: patchview_build.py stl_directory state_file")
    sys.exit(1)

srcdir = sys.argv[1]
state = sys.argv[2]

view = CreateView("RenderView")

for filename in sorted(glob.glob(os.path.join(srcdir, "*.stl"))):

    reader = STLReader(FileNames=[filename])

    name = os.path.splitext(os.path.basename(filename))[0]

    RenameSource(name, reader)

    Show(reader, view)

Render()

SaveState(state)