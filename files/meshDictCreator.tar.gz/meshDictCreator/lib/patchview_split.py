#!/usr/bin/env python3

import os
import re
import sys

if len(sys.argv) != 3:
    print("Usage: patchview_split.py input.stl output_directory")
    sys.exit(1)

src = sys.argv[1]
outdir = sys.argv[2]

with open(src, "rb") as f:
    if not f.read(5).startswith(b"solid"):
        sys.exit("Binary STL is not supported.")

def clean(name):
    name = name.strip()
    if not name or name.lower() == "ascii":
        name = "unnamed"
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name.replace(" ", "_"))

seen = {}
current = None
current_name = None
parts = []

with open(src, "r", errors="ignore") as f:

    for line in f:

        m = re.match(r"^\s*solid\s+(.+?)\s*$", line)

        if m:

            current_name = clean(m.group(1))

            n = seen.get(current_name, 0)
            seen[current_name] = n + 1

            if n > 0:
                current_name = f"{current_name}_{n}"

            current = [f"solid {current_name}\n"]
            continue

        if re.match(r"^\s*endsolid", line):

            if current is not None:

                current.append(f"endsolid {current_name}\n")

                outfile = os.path.join(outdir, current_name + ".stl")

                with open(outfile, "w", newline="\n") as out:
                    out.writelines(current)

                parts.append(outfile)

                current = None
                current_name = None

            continue

        if current is not None:
            current.append(line)

if not parts:
    sys.exit("No solid blocks found.")

print("\n".join(parts))