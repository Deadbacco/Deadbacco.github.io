```bash
meshDictCreator
```

# Genel Bakış

```bash
meshDictCreator, OpenFOAM kullanıcılarının mesh hazırlama sürecini
kolaylaştırmak amacıyla geliştirilmiş bir komut satırı aracıdır.
```

# Proje içerisinde iki temel araç bulunmaktadır:

-   meshDictCreator
-   patchview

```bash
meshDictCreator, cfMesh için gerekli meshDict'in oluşturulmasını
kolaylaştırırken, patchview ise STL dosyalarını otomatik olarak ayırıp
ParaView üzerinde görüntülemeyi sağlar, patchview geometri kontrolü için eklenmiştir.
```

------------------------------------------------------------------------

# Özellikler

```bash
meshDictCreator
```

-   Mesh sözlüğünü etkileşimli olarak oluşturur.

```bash
patchview
```

-   ASCII STL dosyalarını okur.
-   Her “solid” bloğunu ayrı STL dosyasına ayırır.
-   Patch isimlerini korur.
-   ParaView’i otomatik açar.
-   Patch’leri Pipeline Browser’da ayrı nesneler olarak gösterir.

------------------------------------------------------------------------

# Gereksinimler

# Projeyi kullanabilmek için aşağıdaki yazılımların kurulu olması gerekir.

-   OpenFOAM
-   Python 3
-   Windows Subsystem for Linux (WSL)
-   ParaView 5.13.0

# Not: Patchview varsayılan olarak aşağıdaki ParaView kurulum yolunu
kullanmaktadır.

# C:Files.0

------------------------------------------------------------------------

# Proje Yapısı

```text
meshDictCreator/
```

```text
├── bin/ │ ├── meshDictCreator │ └── patchview │ ├── lib/ │ ├──
patchview_split.py │ └── patchview_build.py │ ├── install.sh ├──
uninstall.sh └── README.txt
```

bin/ Komut satırından çalıştırılan araçları içerir.

lib/ PatchView tarafından kullanılan Python dosyalarını içerir.

------------------------------------------------------------------------

# Kurulum

# OpenFOAM ortamını yükledikten sonra proje dizinine giriniz.

```bash
chmod +x install.sh
```

```bash
./install.sh
```

# Kurulum sonunda aşağıdaki komutlar kullanılabilir hale gelir.

```bash
meshDictCreator
```

```bash
patchview
```

------------------------------------------------------------------------

# Kaldırma

```bash
chmod +x uninstall.sh
```

```bash
./uninstall.sh
```

# Bu işlem yalnızca kurulan komutları ve PatchView kütüphanelerini
kaldırır.

# Projenin bulunduğu klasör silinmez.

------------------------------------------------------------------------

```bash
meshDictCreator Kullanımı
```

```bash
meshDictCreator
```

# Komut çalıştırıldıktan sonra program kullanıcıyı adım adım yönlendirir.

simetriye sahip çalışmalarda meshDictCreator kullanılmadan önce patchview ile geometrinin simetri düzlemine göre bulunduğu eksenin kontrol edilmesi önerilir.

Ahmedbody isimli (simetri düzlemi olan) kıyaslama modeli ile örnek bir kullanım en altta verilmiştir.

```bash
meshDictCreatoriçerisinde patchview komutuna denk düşen parapatch komutu, localrefinement, boundaryLayers, renameBoundary kısımlarında patchlerin görsel olarak incelenebilmesi için kullanılır.
```

------------------------------------------------------------------------

# PatchView Kullanımı

```bash
patchview model.stl
```

# Program sırasıyla;

-   STL dosyasını okur.
-   Her solid bloğunu ayırır.
-   Geçici STL dosyalarını oluşturur.
-   ParaView State dosyasını oluşturur.
-   ParaView’i otomatik olarak açar.

------------------------------------------------------------------------

# Geçici Dosyalar

# PatchView aşağıdaki klasörü kullanır.

# C:

# Bu klasörde oluşturulan dosyalar istenildiği zaman silinebilir.

------------------------------------------------------------------------

# Desteklenen STL Formatı

-   ASCII STL

# Binary STL dosyaları desteklenmemektedir.

------------------------------------------------------------------------

# Bilinen Kısıtlamalar

-   ParaView yolu 5.13.0 sürümüne sabitlenmiştir.
-   WSL gerektirir.
-   Binary STL desteklenmez.


# Örnek kullanım: (kullanıc girdilerini özel olarak süslü parantez içine aldım)

{meshDictCreator} (case directory içerisinde.) (meshDict özellikleri için cfmesh userguide'a bakabilirsiniz.)

# Running surfaceCheck...
# STL OK.
# Is there a symmetry plane? (y/n) [n]: {y}
# Body direction? (+x,-x,+y,-y,+z,-z) [+x]: {+z}
# Choose enclosure: box / semisphere / semicylinder [semisphere]: {box}
# Bounding box limits (xMin xMax yMin yMax zMin zMax).
xMin value [9]: {5}
xMax value [9]: {5}
yMin value [9]: {0}
yMax value [9]: {5}
zMin = 0 (symmetry)
zMax value [9]: {5}
# Generating box enclosure STL...
/*---------------------------------------------------------------------------*\
| =========                 |                                                 |
| \\      /  F ield         | OpenFOAM: {The Open Source CFD Toolbox          |
|  \\    /   O peration     | Version:  {2306                                 |
|   \\  /    A nd           | Website:  {www.openfoam.com                     |
|    \\/     M anipulation  |                                                 |
\*---------------------------------------------------------------------------*/
# Build  : _cafbeeb2-20260127 OPENFOAM=2306 patch=260127 version=2306
# Arch   : {"LSB;label=32;scalar=64"}
Exec   : surfaceGenerateBoundingBox ahmedBodyHalf.stl ahmedBodyHalfBox.stl 5 5 0 5 0 5
# Date   : {Jul 17 2026}
# Time   : 21:41:{13}
# Host   : {User-28}
# PID    : {16007}
# I/O    : {uncollated}
# Case   : /home/User/OpenFOAM/User-v2306/run/apptest/ahmedBodysymmetrycopy
nProcs : {1}
trapFpe: Floating point exception trapping enabled (FOAM_SIGFPE).
fileModificationChecking : Monitoring run-time modified files using timeStampMaster (fileModificationSkew 5, maxFileModificationPolls 20)
allowSystemOperations : Allowing user-supplied system call operations

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
# Neg offset (5 0 0)
# Pos offset (5 5 5)
# Surface bounding box (-1.044 0 0) (0 0.338 0.1945)
# Generated bounding box (-6.044 0 0) (5 5.338 5.1945)
# End

surfaceFeatureEdges angle (deg) [90]: {15}
# Extracting feature edges from ahmedBodyHalfBox.stl ...
/*---------------------------------------------------------------------------*\
| =========                 |                                                 |
| \\      /  F ield         | OpenFOAM: {The Open Source CFD Toolbox           |}
|  \\    /   O peration     | Version:  {2306                                  |}
|   \\  /    A nd           | Website:  {www.openfoam.com                      |}
|    \\/     M anipulation  |                                                 |
\*---------------------------------------------------------------------------*/
# Build  : _cafbeeb2-20260127 OPENFOAM=2306 patch=260127 version=2306
# Arch   : {"LSB;label=32;scalar=64"}
# Exec   : surfaceFeatureEdges -angle 15 ahmedBodyHalfBox.stl ahmedBodyHalf.fms
# Date   : {Jul 17 2026}
# Time   : 21:41:{16}
# Host   : {User-28}
# PID    : {16058}
# I/O    : {uncollated}
# Case   : /home/User/OpenFOAM/User-v2306/run/apptest/ahmedBodysymmetrycopy
nProcs : {1}
trapFpe: Floating point exception trapping enabled (FOAM_SIGFPE).
fileModificationChecking : Monitoring run-time modified files using timeStampMaster (fileModificationSkew 5, maxFileModificationPolls 20)
allowSystemOperations : Allowing user-supplied system call operations

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
# Writing : {"ahmedBodyHalf.fms"}
# End

# Feature file: {ahmedBodyHalf.fms}
maxCellSize (or 'not') [0.25]: {0.5}
minCellSize (or 'not') [0.25]: {0.25}
# Use boundaryCellSize? (y/n) [n]: {y}
boundaryCellSizeRefinementThickness (or 'not') [0.05]: {0.05}
boundaryCellSize (or 'not') [0.25]: {0.25}
localRefinement? (y/n) [n]: {y}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Enter patch name or 'getout' (or 'parapatch') [getout]: {ahmedBodyHalf}
cellSize? (y/n) [n]: {y}
cellSize value (or 'not') [0.01]: {0.01}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Enter patch name or 'getout' (or 'parapatch') [getout]: {getout}
objectRefinements? (y/n) [n]: {y}
# Shapes: box, sphere, line, cone. Type 'getout' to finish.
# Shape [getout]: {box}
# Name [box1]: {box1}
centre x (or 'not') [0]: {-0.5}
centre y (or 'not') [0]: {0.2}
centre z (or 'not') [0]: {0.1}
lengthX (or 'not') [1]: {3}
lengthY (or 'not') [1]: {3}
lengthZ (or 'not') [1]: {2}
cellSize (or 'not') [0.01]: {0.02}

# Shapes: box, sphere, line, cone. Type 'getout' to finish.
# Shape [getout]: {getout}
boundaryLayers? (y/n) [n]: {y}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Enter patch name or 'getout' (or 'parapatch') [getout]: {ahmedBodyHalf}
nLayers (or 'not') [5]: {3}
thicknessRatio (or 'not') [1.2]: {1.15}
maxFirstLayerThickness (or 'not') [not]: {not}
allowDiscontinuity (1/0 or 'not') [1]: {1}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Enter patch name or 'getout' (or 'parapatch') [getout]: {getout}
optimiseLayer? (y/n) [y]: {y}
optimisationParameters? (y/n) [n]: {y}
nSmoothNormals (or 'not') [5]: {5}
relThicknessTol (or 'not') [0.4]: {0.4}
featureSizeFactor (or 'not') [0.8]: {0.8}
reCalculateNormals (or 'not') [1]: {1}
maxNumIterations (or 'not') [5]: {3}
renameBoundary? (y/n) [n]: {y}
defaultName (or 'not') [defaultPatch]: {not}
defaultType (or 'not') [wall]: {wall}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Which patch is the symmetry plane? (or 'parapatch' / 'skip') [symmetry]: {zMin}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {yMin}
newName (or 'not' to skip this mapping) [yMin_new]: {bottom}
type (patch/wall/symmetryPlane/inlet/outlet etc., or 'not') [patch]: {patch}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {yMax}
newName (or 'not' to skip this mapping) [yMax_new]: {top}
type (patch/wall/symmetryPlane/inlet/outlet etc., or 'not') [patch]: {patch}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {xMin}
newName (or 'not' to skip this mapping) [xMin_new]: {inlet}
type (patch/wall/symmetryPlane/inlet/outlet etc., or 'not') [patch]: {patch}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {xMax}
newName (or 'not' to skip this mapping) [xMax_new]: {outlet}
type (patch/wall/symmetryPlane/inlet/outlet etc., or 'not') [patch]: {patch}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {zMax}
newName (or 'not' to skip this mapping) [zMax_new]: {side}
type (patch/wall/symmetryPlane/inlet/outlet etc., or 'not') [patch]: {patch}
# Patches (from combined STL):
#  - ahmedBodyHalf
#  - xMax
#  - xMin
#  - yMax
#  - yMin
#  - zMax
#  - zMin
Type 'parapatch' to preview in ParaView (runs: {patchview ahmedBodyHalfBox.stl).}
# Existing patch name or 'getout' (or 'parapatch') [getout]: {getout}
meshDict written: {system/meshDict}
# Done.

# Bu örnek bir meshDict üretimiydi. oluşan dosya şu şekildedir:


/*--------------------------------*- C++ -*----------------------------------*\
| =========                 |                                                |
| \\      /  F ield         | cfMesh: A library for mesh generation          |
|  \\    /   O peration     |                                                |
|   \\  /    A nd           |                                               |
|    \\/     M anipulation  |                                               |
\*---------------------------------------------------------------------------*/
# FoamFile
{
#     version   2.0;
#     format    ascii;
#     class     dictionary;
#     location  "system";
#     object    meshDict;
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

surfaceFile "ahmedBodyHalf.fms";

maxCellSize 0.5; //[m]
minCellSize 0.25; //[m]
boundaryCellSizeRefinementThickness 0.05; //[m]
boundaryCellSize 0.25; //[m]
localRefinement
{
#     ahmedBodyHalf
#     {
#         cellSize 0.01;
#     }

}
objectRefinements
{
#     box1
#     {
#         type    box;
#         centre  ( -0.5 0.2 0.1 );
#         lengthX 3;
#         lengthY 3;
#         lengthZ 2;
#         cellSize 0.02;
#     }
}
boundaryLayers
{
#     patchBoundaryLayers
#     {
#         ahmedBodyHalf
#         {
#             nLayers 3;
#             thicknessRatio 1.15;
#             allowDiscontinuity 1;
#         }

#     }
#     optimiseLayer 1;
#     optimisationParameters
#     {
#         nSmoothNormals 		5;
#         relThicknessTol 		0.4;
#         featureSizeFactor 		0.8;
#         reCalculateNormals 		1;
#         maxNumIterations 		3;
#     }
}
renameBoundary
{
#     defaultType     wall;

#     newPatchNames
#     {
#         "zMin"
#         {
#             newName symmetry;
#             type    symmetryPlane;
#         }
#         "yMin"
#         {
#             newName bottom;
#             type    patch;
#         }
#         "yMax"
#         {
#             newName top;
#             type    patch;
#         }
#         "xMin"
#         {
#             newName inlet;
#             type    patch;
#         }
#         "xMax"
#         {
#             newName outlet;
#             type    patch;
#         }
#         "zMax"
#         {
#             newName side;
#             type    patch;
#         }
#     }
}
// ************************************************************************* //

